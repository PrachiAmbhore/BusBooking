export interface Alert {
    type: 'success' | 'info' | 'warning' | 'danger';
    message: string;
}
