export interface Captcha {
    id: number;
    captcha?: string;
    captchaImage?: string;
}
