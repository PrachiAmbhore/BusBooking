export interface Authority {
    authority: string;
}
