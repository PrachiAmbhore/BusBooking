export interface PriceTable {
    id?: number;
    pricePerKilometer: number;
    taxPercent: number;
}
