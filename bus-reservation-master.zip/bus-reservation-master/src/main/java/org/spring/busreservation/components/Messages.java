package org.spring.busreservation.components;

public interface Messages {
    String getMessage(String code);
}
